from flask import Flask, send_from_directory, render_template, request, redirect, url_for, flash, session,send_file
import os
from app import app
from models import db, User, Campaign, CampaignRequest, Bookmark, Influencer, Transaction, Rating, Sponsor, AdRequest
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
from functools import wraps
import re
import csv
from io import StringIO

def admin_required(func):
    @wraps(func)
    def inner(*args,**kwargs):
        if 'user_id' not in session: 
            flash('Please login to continue')
            return redirect(url_for('login'))
        user=User.query.get(session['user_id'])
        if not user.role=='Admin':
            flash("You are not authorized to access this page")
            return redirect(url_for('index'))
        return func(*args,**kwargs)
    return inner

def auth_required(func):
    @wraps(func)
    def inner(*args,**kwargs):
        if 'user_id' in session:
            return func(*args,**kwargs)
        else: 
            flash('Please login to continue')
            return redirect(url_for('login'))
    return inner

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/login')
def login():
    return render_template('login.html')

@app.route('/register')
def register():
    return render_template('register.html')

@app.route('/index')
def index():
    return render_template('index.html')

@app.route('/forgot')
def forgot():
    return render_template('forgot.html')



@app.route('/login', methods=['POST'])
def login_post():
    email = request.form.get('email')
    password = request.form.get('password')
    role = request.form.get('role')
    

    if not email or not password or not role:
        flash('Please fill out all the fields')
        return redirect(url_for('login'))
    user=User.query.filter_by(email=email).first()

    if not user:
        flash('User does not exist')
        return redirect(url_for('login'))
    
    if not check_password_hash(user.password, password):
        flash('Incorrect password')
        return redirect(url_for('login'))

    if user.role != role:
        flash('Incorrect role selected')
        return redirect(url_for('login'))
    
    session['user_id'] = user.id

    today = datetime.today().date()
    campaigns = Campaign.query.all()
    
    for campaign in campaigns:

        start_date = campaign.start_date.date() if isinstance(campaign.start_date, datetime) else campaign.start_date
        end_date = campaign.end_date.date() if isinstance(campaign.end_date, datetime) else campaign.end_date


        if today > end_date:
            status = "Expired"
        elif today < start_date:
            status = "Upcoming"
        else:
            status = "Ongoing"
        
        # Update the campaign status if it has changed
        if campaign.status != status:
            campaign.status = status
            
    db.session.commit()

    if role == 'Influencer':
        influencer = Influencer.query.filter_by(user_id=user.id).first()
        campaign = Campaign.query.all()
        if influencer and influencer.profile_picture and influencer.niche and influencer.platform and influencer.reach:
            return render_template('find_campaign_influencer.html',influencer=influencer,campaign=campaign)
        else:
            return redirect(url_for('complete_profile'))
    elif role == 'Admin':
        return redirect(url_for('admin'))
    elif role == 'Sponsor':
        sponsor = Sponsor.query.filter_by(user_id=user.id).first()
        campaign=Campaign.query.filter_by(user_id=user.id).all()
        if sponsor and sponsor.profile_picture and sponsor.company and sponsor.bank_balance:
            return render_template('sponsor.html',sponsor=sponsor,campaign=campaign)
        else:
            return redirect(url_for('complete_sponsor_profile'))
    

    return redirect(url_for('login'))

@app.route('/register', methods=['POST'])
def register_post():
    name = request.form.get('name')
    email = request.form.get('email')
    dob = request.form.get('dob')
    password = request.form.get('password')
    role = request.form.get('role')
    niche = request.form.get('niche')

    if not name or not email or not dob or not password or not role or not niche:
        flash('Please fill out all the fields')
        return redirect(url_for('register'))
    
    user=User.query.filter_by(email=email).first()

    if user:
        flash('Username already exists')
        return redirect(url_for('register'))
    
    password_hash = generate_password_hash(password)

    dob = datetime.strptime(dob, '%Y-%m-%d').date()
    new_user = User(email=email,name=name,password=password_hash,dob=dob,role=role,niche=niche)
    
    db.session.add(new_user)
    db.session.commit()
    return redirect(url_for('login'))





@app.route('/profile')
@auth_required
def profile():
    user = User.query.get(session['user_id'])
    return render_template('profile.html', user=user)


@app.route('/complete_profile')
def complete_profile():
    return render_template('complete_profile.html')

@app.route('/complete_profile', methods=['POST'])
@auth_required
def complete_profile_post():

    if request.method == 'POST':
        profile_pic = request.form.get('profile_picture')
        platform = request.form.get('platform')
        niche = request.form.get('niche')
        reach = request.form.get('reach')

        if not profile_pic or not reach or not platform or not niche:
            flash('Please fill out all the fields')
            return redirect(url_for('complete_profile'))

        influencer = Influencer.query.filter_by(user_id=session['user_id']).first()
        if not influencer:
            user = User.query.get(session['user_id'])
            influencer = Influencer(
                user_id=user.id,
                name=user.name,
                email=user.email,
                profile_picture=profile_pic,
                platform=platform,
                niche=niche,
                reach=reach,
                bank_balance=0.0,  
                flagged=False
            )
            db.session.add(influencer)
        else:
            influencer.profile_picture = profile_pic
            influencer.platform = platform
            influencer.niche = niche
            influencer.reach = reach

        db.session.commit()
        flash('Profile updated successfully')
    
        campaign = Campaign.query.all()
        
        return render_template('find_campaign_influencer.html',influencer=influencer,campaign=campaign)
        
    return redirect(url_for('complete_profile'))
    




@app.route('/profile', methods=['POST'])
@auth_required
def profile_post():
    email = request.form.get('email')
    cpassword = request.form.get('cpassword')
    password = request.form.get('password')
    name = request.form.get('name')

    if not email or not cpassword or not password:
        flash('Please fill out all the required fields')
        return redirect(url_for('profile'))
    
    user = User.query.get(session['user_id'])
    if not check_password_hash(user.password, cpassword):
        flash('Incorrect password')
        return redirect(url_for('profile'))
    
    if email != user.email:
        new_email = User.query.filter_by(email=email).first()
        if new_email:
            flash('Username already exists')
            return redirect(url_for('profile'))
    
    new_password_hash = generate_password_hash(password)
    user.email = email
    user.password = new_password_hash
    user.name = name
    db.session.commit()
    flash('Profile updated successfully')
    return redirect(url_for('profile'))



@app.route('/complete_sponsor_profile')
@auth_required
def complete_sponsor_profile():
    return render_template('complete_sponsor_profile.html')


@app.route('/complete_sponsor_profile', methods=['POST'])
@auth_required
def complete_sponsor_profile_post():
    if request.method == 'POST':
        profile_pic = request.form.get('profile_picture')
        company = request.form.get('company')
        bank_balance = request.form.get('bank_balance')

        if not profile_pic or not company or not bank_balance:
            flash('Please fill out all the fields')
            return redirect(url_for('complete_sponsor_profile'))

        sponsor = Sponsor.query.filter_by(user_id=session['user_id']).first()
        if not sponsor:
            user = User.query.get(session['user_id'])
            sponsor = Sponsor(
                user_id=user.id,
                name=user.name,
                email=user.email,
                profile_picture=profile_pic,
                company=company,
                bank_balance=bank_balance,  
                flagged=False
            )
            db.session.add(sponsor)
        else:
            sponsor.profile_picture = profile_pic
            sponsor.company = company
            sponsor.bank_balance = bank_balance

        db.session.commit()
        flash('Profile updated successfully')
        return redirect(url_for('sponsor'))
        
    return redirect(url_for('complete_sponsor_profile'))



@app.route('/logout')
@auth_required
def logout():
    session.pop('user_id')
    return redirect(url_for('login'))



#Sponsor------------------------------------------------------------------------------------------------------------------------------------------------------------------

@app.route('/sponsor')
@auth_required
def sponsor():
    sponsor = Sponsor.query.filter_by(user_id=session['user_id']).first()
    
    campaign = Campaign.query.filter_by(user_id=sponsor.user_id).all()

    return render_template('sponsor.html', sponsor=sponsor, campaign=campaign)



@app.route('/add_campaign')
@auth_required
def add_campaign():
    sponsor = Sponsor.query.filter_by(user_id=session['user_id']).first()
    return render_template('add_campaign.html',sponsor=sponsor)


@app.route('/edit_campaign/<int:id>')
@auth_required
def edit_campaign(id):
    sponsor = Sponsor.query.filter_by(user_id=session['user_id']).first()
    campaign = Campaign.query.get(id)
    return render_template('edit_campaign.html',sponsor=sponsor, campaign=campaign)

#Sponsor CRUD------------------------------------------------------------------------------------------------------------------------------------------------------------


@app.route('/list_campaigns', methods=['GET'])
@auth_required
def list_campaigns():
    name = request.args.get('name')
    niche = request.args.get('niche')

    # Get the logged-in sponsor's user_id
    sponsor = Sponsor.query.filter_by(user_id=session['user_id']).first()

    # Query the database with filters
    query = Campaign.query.filter_by(user_id=sponsor.user_id)
    
    if name:
        query = query.filter(Campaign.name.ilike(f'%{name}%'))
    if niche:
        query = query.filter(Campaign.niche.ilike(f'%{niche}%'))

    campaign = query.all()

    # Render the template with the filtered campaigns
    return render_template('sponsor.html', sponsor=sponsor, campaign=campaign)




@app.route('/sponsor/<int:id>', methods=['GET'])
@auth_required
def view_campaign(id):
    campaign = Campaign.query.get_or_404(id)  
    return render_template('sponsor.html', campaign=campaign)



@app.route('/add_campaign', methods=['POST'])
@auth_required
def add_campaign_post():
    name = request.form.get('name')
    description = request.form.get('description')
    start_date = request.form.get('start_date')
    end_date = request.form.get('end_date')
    budget = request.form.get('budget')
    goals = request.form.get('goals')
    niche = request.form.get('niche')
    user_id = session['user_id']
    visibility = request.form.get('visibility')
    if not name or not description or not start_date or not end_date or not niche or not budget or not goals:
        flash('Please fill out all fields')
        return redirect(url_for('add_campaign'))
    
    start = datetime.strptime(start_date, '%Y-%m-%d').date()
    end = datetime.strptime(end_date, '%Y-%m-%d').date()

    today = datetime.today().date()
    if today > end:
        status = "Expired"
    elif today < start:
        status = "Upcoming"
    else:
        status = "Ongoing"


    campaign = Campaign(name=name,description=description,start_date=start,end_date=end,niche=niche,goals=goals,budget=budget,status=status,flagged=False,user_id=user_id,visibility=visibility)
    db.session.add(campaign)
    db.session.commit()

    flash('Campaign added successfully')
    return redirect(url_for('sponsor'))
    


@app.route('/edit_campaign/<int:id>', methods=['POST'])
@auth_required
def edit_campaign_post(id):
    # Ensure user is logged in
    campaign = Campaign.query.get_or_404(id)

    # Ensure the user has permission to edit this campaign
    if campaign.user_id != session['user_id']:
        flash('You do not have permission to edit this campaign.', 'danger')
        return redirect(url_for('sponsor'))

    if request.method == 'POST':
        # Get data from form
        name = request.form.get('name')
        description = request.form.get('description')
        start_date = request.form.get('start_date')
        end_date = request.form.get('end_date')
        budget = request.form.get('budget')
        visibility = request.form.get('visibility')
        goals = request.form.get('goals')
        niche = request.form.get('niche')
        if not name or not description or not start_date or not end_date or not budget or not visibility or not goals or not niche:
            flash('Please fill out all fields')
            return redirect(url_for('edit_campaign', id=id))
        campaign.name=name
        campaign.description=description
        campaign.start_date=datetime.strptime(start_date, '%Y-%m-%d').date()
        campaign.end_date=datetime.strptime(end_date, '%Y-%m-%d').date()
        campaign.budget=budget
        campaign.visibility=visibility
        campaign.goals=goals
        campaign.niche=niche
        # Commit changes to the database
        db.session.commit()
        flash('Campaign updated successfully!', 'success')
        return redirect(url_for('sponsor'))

    # Render the edit form with the current campaign details
    return render_template('edit_campaign.html', campaign=campaign)




@app.route('/sponsor/<int:id>', methods=['POST'])
@auth_required
def delete_campaign(id):
    print(id)
    campaign = Campaign.query.get_or_404(id)  
    try:
        db.session.delete(campaign)  
        db.session.commit()  
        flash('Campaign deleted successfully.', 'success')  
    except Exception as e:
        db.session.rollback()  
        flash('An error occurred while deleting the campaign. Please try again.', 'danger')
    return redirect(url_for('sponsor'))


#Not required
@app.route('/ajaxfile', methods=['POST'])
def ajaxfile():
    user_id = request.form.get('userid')
    # Query the database for user details
    user = db.session.query(User).filter_by(id=user_id).first()  # Adjust this line based on your User model

    if user:
        # Render the user information as HTML
        html = render_template('response.html', employeelist=[user])
        return html
    return "User not found", 404



@app.route('/send_request', methods=['POST'])
def send_request():
    # Retrieve form data
    campaign_id = request.form.get('campaign_id')
    influencer_id = request.form.get('influencer_id')
    campaign_name = request.form.get('campaign_name')
    messages = request.form.get('messages')
    requirements = request.form.get('requirements')
    payment_amount = float(request.form.get('payment_amount'))
    
    campaign = Campaign.query.filter_by(name=campaign_name).first()
    # Create a new CampaignRequest instance
    new_request = CampaignRequest(
        campaign_id=campaign.id,
        influencer_id=influencer_id,
        messages=messages,
        requirements=requirements,
        payment_amount=payment_amount,
        status='Pending',  # Default status or adjust as needed
        completed=False,
        completion_confirmed=False,
        payment_done=False,
        rating_done=False
    )
    
    # Add the request to the database
    db.session.add(new_request)
    db.session.commit()

    flash('Request sent successfully!', 'success')
    return redirect(url_for('find_influencer'))


@app.route('/send_back_request', methods=['POST'])
def send_back_request():
    # Retrieve form data
    request_id = request.form.get('request_id')
    campaign_id = request.form.get('campaign_id')
    influencer_id = request.form.get('influencer_id')
    campaign_name = request.form.get('campaign_name')
    messages = request.form.get('messages')
    requirements = request.form.get('requirements')
    payment_amount = float(request.form.get('payment_amount'))
    
    new_request = CampaignRequest.query.filter_by(id=request_id).first()
    # Add the request to the database
    if new_request:
        new_request.messages=messages
        new_request.payment_amount=payment_amount
        new_request.requirements=requirements
        new_request.status='Pending'
    else:
        flash('Request not found.','danger')
    

    db.session.commit()

    flash('Request sent successfully!', 'success')
    return redirect(url_for('find_influencer'))


@app.route('/sent_request')
def sent_request():
    
    sponsor = Sponsor.query.filter_by(user_id=session['user_id']).first()
    campaign = Campaign.query.filter_by(user_id=sponsor.user_id).all()
    requests=[]
    for campaign in campaign:
        campaign_requests = CampaignRequest.query.filter_by(campaign_id=campaign.id).all()
        for request in campaign_requests:
            requests.append(request)
    
    return render_template('sent_request.html', requests=requests, sponsor=sponsor)


@app.route('/influencer_request')
def influencer_request():
    
    sponsor = Sponsor.query.filter_by(user_id=session['user_id']).first()
    campaign = Campaign.query.filter_by(user_id=sponsor.user_id).all()
    requests=[]
    for campaign in campaign:
        campaign_requests = AdRequest.query.filter_by(campaign_id=campaign.id).all()
        for request in campaign_requests:
            requests.append(request)
    return render_template('influencer_request.html',requests=requests, sponsor=sponsor)



@app.route('/completed_request')
def completed_request():
    #campaign_requests = CampaignRequest.query.all()
    sponsor = Sponsor.query.filter_by(user_id=session['user_id']).first()

    campaigns = Campaign.query.filter_by(user_id=sponsor.user_id).all()
    campaign_requests=[]
    for campaign in campaigns:
        campaign_request = CampaignRequest.query.filter_by(campaign_id=campaign.id,status='Accepted',completed=True).all()
        for request in campaign_request:
            campaign_requests.append(request)
    ad_requests=[]
    for campaign in campaigns:
        ad_request = AdRequest.query.filter_by(campaign_id=campaign.id,status='Accepted',completed=True).all()
        for request in ad_request:
            ad_requests.append(request)
    transactions = Transaction.query.filter_by(user_id=sponsor.user_id).all()
    print(transactions)
    transactions_dict = {}
    for transaction in transactions:
        if transaction.ad_request_id not in transactions_dict:
            transactions_dict[transaction.ad_request_id] = []
        transactions_dict[transaction.ad_request_id].append(transaction)
    
    return render_template('completed_request.html', requests=ad_requests, sponsor=sponsor,influencer=influencer, requests1=campaign_requests,transactions_dict=transactions_dict)



@app.route('/confirm_task/<int:request_id>')
def confirm_task(request_id):
    ad_request = AdRequest.query.get(request_id)
    
    if not ad_request:
        flash('Ad request not found','danger')
        return redirect(url_for('your_sent_requests'))

    ad_request.completion_confirmed = True

    # Commit changes to the database
    db.session.commit()

    flash('Task Complete! Payment Option is now available.','success')
    return redirect(url_for('completed_request'))




@app.route('/mark_incomplete/<int:request_id>')
def mark_incomplete(request_id):
    ad_request = AdRequest.query.get(request_id)
    
    if not ad_request:
        flash('Ad request not found','danger')
        return redirect(url_for('your_sent_requests'))
    ad_request.completed=False
    ad_request.completion_confirmed = False  # Mark the request as not completed again

    # Commit changes to the database
    db.session.commit()

    flash('Task Incomplete! Task has been reopened for review.','danger')
    return redirect(url_for('completed_request'))
    




@app.route('/confirm_task1/<int:request_id>')
def confirm_task1(request_id):
    campaign_request = CampaignRequest.query.get(request_id)
    
    if not campaign_request:
        flash('Ad request not found','danger')
        return redirect(url_for('your_sent_requests'))

    campaign_request.completion_confirmed = True

    # Commit changes to the database
    db.session.commit()

    flash('Task Complete! Payment Option is now available','success')
    return redirect(url_for('completed_request'))




@app.route('/mark_incomplete1/<int:request_id>')
def mark_incomplete1(request_id):
    campaign_request = CampaignRequest.query.get(request_id)
    
    if not campaign_request:
        flash('Ad request not found','danger')
        return redirect(url_for('your_sent_requests'))
    campaign_request.completed = False
    campaign_request.completion_confirmed = False  # Mark the request as not completed again

    # Commit changes to the database
    db.session.commit()

    flash('Task Incomplete! Task has been reopened for review.','danger')
    return redirect(url_for('completed_request'))











@app.route('/make_payment/<int:request_id>')
def make_payment_page(request_id):
    sponsor = Sponsor.query.filter_by(user_id=session['user_id']).first()
    return render_template('make_payment.html', sponsor=sponsor, request_id=request_id)



@app.route('/make_payment/<int:request_id>', methods=['GET', 'POST'])
def make_payment(request_id):
    if request.method == 'POST':
        card_number = request.form.get('card_number')
        card_expiry = request.form.get('expiry_date')
        cvc = request.form.get('cvc')
        cardholder_name = request.form.get('cardholder_name')
        state = request.form.get('state')
        country = request.form.get('country')
        ad_request_id = request.form.get('ad_request_id')

        # Validation
        errors = []

        if not re.match(r'^\d{16}$', card_number):
            errors.append('Card number must be 16 digits.')
        if not re.match(r'^\d{3}$', cvc):
            errors.append('CVC must be 3 digits.')

        today = datetime.today().date()
        try:
            exp_month, exp_year = map(int, card_expiry.split('/'))
            exp_date = datetime(year=exp_year + 2000, month=exp_month, day=1).date()
            if today > exp_date:
                errors.append('Card has expired.','danger')
        except ValueError:
            errors.append('Invalid expiry date format.','danger')

        if errors:
            for error in errors:
                flash(error, 'error')
            return redirect(url_for('make_payment', request_id=request_id))

        # Create Transaction
        ad_request = AdRequest.query.get(ad_request_id)
        if not ad_request:
            flash('Ad Request not found.','danger')
            return redirect(url_for('completed_request'))

        transaction = Transaction(
            influencer_id=ad_request.influencer_id,
            amount=ad_request.payment_amount,
            status='Completed',
            date=datetime.utcnow(),
            ad_request_id=ad_request.id,
            user_id=session.get('user_id'),
            request_type='RECEIVED'
        )
        influencer = Influencer.query.get(ad_request.influencer_id)
        if not influencer:
            flash('Influencer not found.','danger')
            return redirect(url_for('completed_request'))
        
        db.session.add(transaction)
        influencer.bank_balance += ad_request.payment_amount

        db.session.commit()

        # Update AdRequest status
        ad_request.completed = True
        ad_request.payment_done = True
        db.session.commit()

        flash('Payment processed successfully!', 'success')
        return redirect(url_for('completed_request'))

    return render_template('make_payment.html', request_id=request_id)










@app.route('/make_payment1/<int:request_id>')
def make_payment_page1(request_id):
    sponsor = Sponsor.query.filter_by(user_id=session['user_id']).first()
    return render_template('make_payment1.html', sponsor=sponsor, request_id=request_id)



@app.route('/make_payment1/<int:request_id>', methods=['GET', 'POST'])
def make_payment1(request_id):
    if request.method == 'POST':
        card_number = request.form.get('card_number')
        card_expiry = request.form.get('expiry_date')
        cvc = request.form.get('cvc')
        cardholder_name = request.form.get('cardholder_name')
        state = request.form.get('state')
        country = request.form.get('country')
        campaign_request_id = request.form.get('campaign_request_id')

        # Validation
        errors = []

        if not re.match(r'^\d{16}$', card_number):
            errors.append('Card number must be 16 digits.')
        if not re.match(r'^\d{3}$', cvc):
            errors.append('CVC must be 3 digits.')

        today = datetime.today().date()
        try:
            exp_month, exp_year = map(int, card_expiry.split('/'))
            exp_date = datetime(year=exp_year + 2000, month=exp_month, day=1).date()
            if today > exp_date:
                errors.append('Card has expired.','danger')
        except ValueError:
            errors.append('Invalid expiry date format.','danger')

        if errors:
            for error in errors:
                flash(error, 'error')
            return redirect(url_for('make_payment1', request_id=request_id))

        # Create Transaction
        campaign_request = CampaignRequest.query.get(campaign_request_id)
        if not campaign_request:
            flash('Ad Request not found.','danger')
            return redirect(url_for('completed_request'))

        transaction = Transaction(
            influencer_id=campaign_request.influencer_id,
            amount=campaign_request.payment_amount,
            date=datetime.utcnow(),  # Set the date to the current time
            status='Completed',
            ad_request_id=campaign_request.id,
            user_id=session.get('user_id'),
            request_type='SENT'
        )
        influencer = Influencer.query.get(campaign_request.influencer_id)
        if not influencer:
            flash('Influencer not found.','danger')
            return redirect(url_for('completed_request'))
        
        db.session.add(transaction)
        influencer.bank_balance += campaign_request.payment_amount

        db.session.commit()

        # Update AdRequest status
        campaign_request.completed = True
        campaign_request.payment_done = True
        db.session.commit()

        flash('Payment processed successfully!', 'success')
        return redirect(url_for('completed_request'))
    


@app.route('/transaction_history', methods=['GET', 'POST'])
def transaction_history():
    if request.method == 'POST':
        if 'export_csv' in request.form:
            return export_csv()
    sponsor = Sponsor.query.filter_by(user_id=session['user_id']).first()
    # Fetch transactions from the database
    transactions = Transaction.query.filter_by(user_id=session['user_id']).all()  # Adjust according to your query

    return render_template('transaction_history.html', transactions=transactions, sponsor=sponsor)

@app.route('/export_csv')
def export_csv():
    # Fetch transactions from the database
    transactions = Transaction.query.all()  # Adjust according to your query

    # Create an in-memory output file for the CSV data
    output = StringIO()
    writer = csv.writer(output)
    writer.writerow(['Request Type', 'Influencer Name', 'Payment Amount', 'Completion Status', 'Transaction Time'])

    for transaction in transactions:
        writer.writerow([
            transaction.request_type,
            transaction.influencer.name,
            transaction.amount,
            transaction.status,
            transaction.date
        ])

    output.seek(0)

    return send_file(
        output,
        mimetype='text/csv',
        as_attachment=True,
        attachment_filename='transactions.csv'
    )







#Influencer-----------------------------------------------------------------------------------------------------------------------------------------



@app.route('/influencer')
@auth_required
def influencer():
    influencer = Influencer.query.filter_by(user_id=session['user_id']).first()
    campaign = Campaign.query.all()
    return render_template('find_campaign_influencer.html',campaign=campaign,influencer=influencer)


@app.route('/find_campaign_influencer')
def find_campaign_influencer():
    influencer = Influencer.query.filter_by(user_id=session['user_id']).first()
    campaign = Campaign.query.all()
    return render_template('find_campaign_influencer.html',campaign=campaign,influencer=influencer)

@app.route('/find_influencer')
@auth_required
def find_influencer():
    influencer = Influencer.query.all()
    sponsor = Sponsor.query.filter_by(user_id=session['user_id']).first()
    campaign = Campaign.query.filter_by(user_id=session['user_id']).first()
    return render_template('find_influencer.html',campaign=campaign,influencer=influencer,sponsor=sponsor)




@app.route('/list_influencers', methods=['GET'])
@auth_required
def list_influencers():
    name = request.args.get('name')
    niche = request.args.get('niche')
    platform = request.args.get('platform')
    sort_order = request.args.get('sortOrder', 'asc')
    campaign = Campaign.query.filter_by(user_id=session['user_id']).first()
    # Query the database with filters
    query = Influencer.query
    
    if name:
        query = query.filter(Influencer.name.ilike(f'%{name}%'))
    if niche:
        query = query.filter(Influencer.niche.ilike(f'%{niche}%'))
    if platform:
        query = query.filter(Influencer.platform.ilike(f'%{platform}%'))

    if sort_order == 'asc':
        query = query.order_by(Influencer.reach.asc())
    else:
        query = query.order_by(Influencer.reach.desc())
    
    influencer = query.all()

    sponsor = Sponsor.query.filter_by(user_id=session['user_id']).first()
    # Render the template with the filtered influencers
    return render_template('find_influencer.html', sponsor=sponsor, influencer=influencer,campaign=campaign)


@app.route('/list_influencer_campaigns', methods=['GET'])
@auth_required
def list_influencer_campaigns():
    name = request.args.get('name')
    niche = request.args.get('niche')

    # Query the database with filters
    query = Campaign.query
    
    if name:
        query = query.filter(Campaign.name.ilike(f'%{name}%'))
    if niche:
        query = query.filter(Campaign.niche.ilike(f'%{niche}%'))

    campaign = query.all()
    influencer = Influencer.query.filter_by(user_id=session['user_id']).first()
    sponsor = Sponsor.query.filter_by(user_id=session['user_id']).first()
    # Render the template with the filtered campaigns
    return render_template('find_campaign_influencer.html',sponsor=sponsor, campaign=campaign,influencer=influencer)


@app.route('/send_influencer_request', methods=['POST'])
def send_influencer_request():
    # Retrieve form data
    campaign_id = request.form.get('campaign_id')
    influencer_id = request.form.get('influencer_id')
    messages = request.form.get('messages')
    requirements = request.form.get('requirements')
    payment_amount = float(request.form.get('payment_amount'))
    
    # Create a new CampaignRequest instance
    new_request = AdRequest(
        campaign_id=campaign_id,
        influencer_id=influencer_id,
        messages=messages,
        requirements=requirements,
        payment_amount=payment_amount,
        status='Pending',  # Default status or adjust as needed
        completed=False,
        completion_confirmed=False,
        payment_done=False,
        rating_done=False
    )
    
    # Add the request to the database
    db.session.add(new_request)
    db.session.commit()

    flash('Request sent successfully!', 'success')
    return redirect(url_for('find_campaign_influencer'))



@app.route('/approve_request/<int:request_id>', methods=['POST'])
def approve_request(request_id):
    request = AdRequest.query.get(request_id)
    if request:
        request.status = 'Accepted'
        request.completed = False
        db.session.commit()
        flash('Request approved successfully!', 'success')
    else:
        flash('Request not found.', 'error')
    return redirect(url_for('influencer_request'))

@app.route('/reject_request/<int:request_id>', methods=['POST'])
def reject_request(request_id):
    request = AdRequest.query.get(request_id)
    if request:
        request.status = 'Rejected'
        db.session.commit()
        flash('Request rejected successfully!', 'warning')
    else:
        flash('Request not found.', 'error')
    return redirect(url_for('influencer_request'))

@app.route('/campaigns_undertaken')
def campaigns_undertaken():
    influencer = Influencer.query.filter_by(user_id=session['user_id']).first()
    ad_requests = AdRequest.query.filter_by(influencer_id=influencer.id, status='Accepted', completed=False).all()
    campaign_requests = CampaignRequest.query.filter_by(influencer_id=influencer.id, status='Accepted', completed=False).all()
    campaigns = []
    for ad_request in ad_requests:
        campaign = Campaign.query.get(ad_request.campaign_id)
        if campaign:
            campaigns.append(campaign)
    for campaign_request in campaign_requests:
        campaign1 = Campaign.query.get(campaign_request.campaign_id)
        if campaign1:
            campaigns.append(campaign1)
    return render_template('campaigns_undertaken.html', campaign=campaigns, influencer=influencer, requests=ad_requests, requests1=campaign_requests)

@app.route('/list_campaigns_undertaken', methods=['GET'])
@auth_required
def list_campaigns_undertaken():

    influencer = Influencer.query.filter_by(user_id=session['user_id']).first()
    
    # Get the search parameters from the request
    name = request.args.get('name')
    niche = request.args.get('niche')
    
    # Get the accepted and not completed ad requests for the influencer
    ad_requests = AdRequest.query.filter_by(influencer_id=influencer.id, status='Accepted', completed=False).all()

    # Initialize the list of campaigns
    campaigns = []
    filtered_ad_requests = []
    
    for ad_request in ad_requests:
        campaign = Campaign.query.get(ad_request.campaign_id)
        if campaign:
            # Append campaigns that match the filters
            if name:
                if (name.lower() in campaign.name.lower()):
                    campaigns.append(campaign)
                    filtered_ad_requests.append(ad_request)
            if niche:
                if (niche.lower() in campaign.niche.lower()):
                    campaigns.append(campaign)
                    filtered_ad_requests.append(ad_request)
    
    # Render the template with filtered campaigns
    return render_template('campaigns_undertaken.html', campaign=campaigns, influencer=influencer, requests=filtered_ad_requests)
    

@app.route('/mark_completed/<int:request_id>')
def mark_completed(request_id):
    # Fetch the AdRequest by ID
    ad_request = AdRequest.query.get(request_id)

    if not ad_request:
        flash('Ad request not found')
        return redirect(url_for('list_campaigns_undertaken'))

    # Update the completed attribute to True
    ad_request.completed = True

    # Commit changes to the database
    db.session.commit()

    flash('Ad request marked as completed')
    return redirect(url_for('campaigns_undertaken'))



@app.route('/mark_completed1/<int:request_id>')
def mark_completed1(request_id):
    # Fetch the AdRequest by ID
    campaign_request = CampaignRequest.query.get(request_id)

    if not campaign_request:
        flash('Ad request not found','danger')
        return redirect(url_for('list_campaigns_undertaken'))

    # Update the completed attribute to True
    campaign_request.completed = True

    # Commit changes to the database
    db.session.commit()

    flash('Ad request marked as completed','success')
    return redirect(url_for('campaigns_undertaken'))





@app.route('/influencer_sent_request')
def influencer_sent_request():

    influencer = Influencer.query.filter_by(user_id=session['user_id']).first()
    ad_requests = AdRequest.query.filter_by(influencer_id=influencer.id, completed=False).all()
    
    return render_template('influencer_sent_request.html',influencer=influencer,requests=ad_requests)






@app.route('/approve/<int:request_id>', methods=['POST'])
def approve(request_id):
    request = CampaignRequest.query.get(request_id)
    if request:
        request.status = 'Accepted'
        request.completed = False
        db.session.commit()
        flash('Request approved successfully!', 'success')
    else:
        flash('Request not found.', 'error')
    return redirect(url_for('sponsor_request'))



@app.route('/reject/<int:request_id>', methods=['POST'])
def reject(request_id):
    request = CampaignRequest.query.get(request_id)
    if request:
        request.status = 'Rejected'
        db.session.commit()
        flash('Request rejected successfully!', 'warning')
    else:
        flash('Request not found.', 'error')
    return redirect(url_for('influencer_request'))




@app.route('/sponsor_request')
def sponsor_request():
    user_id = session.get('user_id')
    
    influencer = Influencer.query.filter_by(user_id=user_id).first()
    requests = CampaignRequest.query.filter_by(influencer_id=influencer.id).all()

    sponsors = {}
    for request in requests:
        campaign = Campaign.query.get(request.campaign_id)
        if campaign:
            sponsor = Sponsor.query.filter_by(user_id=campaign.user_id).first()
            if sponsor:
                sponsors[request.id] = sponsor

    return render_template('sponsor_request.html', requests=requests, influencer=influencer, sponsor=sponsors)


@app.route('/negotiate/<int:request_id>', methods=['POST'])
def negotiate(request_id):
    request_to_negotiate = CampaignRequest.query.get_or_404(request_id)
    negotiation_message = request.form.get('negotiation_message')
    if request_to_negotiate:
        request_to_negotiate.messages=negotiation_message
        request_to_negotiate.status = 'Rejected'
        db.session.commit()
        flash('Negotiation message sent.', 'success')
    else:
        flash('Request not found.', 'danger')
    return redirect(url_for('sponsor_request'))


@app.route('/completed_influencer_request')
def completed_influencer_request():
    user_id = session.get('user_id')
    
    influencer = Influencer.query.filter_by(user_id=user_id).first()
    campaign_requests = CampaignRequest.query.filter_by(influencer_id=influencer.id,payment_done=True).all()
    ad_requests = AdRequest.query.filter_by(influencer_id=influencer.id,payment_done=True).all()
    transactions= Transaction.query.filter_by(influencer_id=influencer.id).all()

    sponsors = {}
    for request in campaign_requests:
        campaign = Campaign.query.get(request.campaign_id)
        if campaign:
            sponsor = Sponsor.query.filter_by(user_id=campaign.user_id).first()
            if sponsor:
                sponsors[request.id] = sponsor
    for request in ad_requests:
        campaign = Campaign.query.get(request.campaign_id)
        if campaign:
            sponsor = Sponsor.query.filter_by(user_id=campaign.user_id).first()
            if sponsor:
                sponsors[request.id] = sponsor
    transactions_dict = {}
    for transaction in transactions:
        if transaction.ad_request_id not in transactions_dict:
            transactions_dict[transaction.ad_request_id] = []
        transactions_dict[transaction.ad_request_id].append(transaction)
    return render_template('completed_influencer_request.html',requests=campaign_requests,requests1=ad_requests,influencer=influencer,sponsor=sponsors,transactions_dict=transactions_dict)
    



@app.route('/send_back_influencer_request', methods=['POST'])
def send_back_influencer_request():
    # Retrieve form data
    request_id = request.form.get('request_id')
    campaign_id = request.form.get('campaign_id')
    influencer_id = request.form.get('influencer_id')
    campaign_name = request.form.get('campaign_name')
    messages = request.form.get('messages')
    requirements = request.form.get('requirements')
    payment_amount = float(request.form.get('payment_amount'))
    
    new_request = AdRequest.query.filter_by(id=request_id).first()
    # Add the request to the database
    if new_request:
        new_request.messages=messages
        new_request.payment_amount=payment_amount
        new_request.requirements=requirements
        new_request.status='Pending'
    else:
        flash('Request not found.','danger')
    

    db.session.commit()

    flash('Request sent successfully!', 'success')
    return redirect(url_for('influencer_sent_request'))



@app.route('/send_back_sponsor_request', methods=['POST'])
def send_back_sponsor_request():
    # Retrieve form data
    request_id = request.form.get('request_id')
    campaign_id = request.form.get('campaign_id') 
    influencer_id = request.form.get('influencer_id')
    campaign_name = request.form.get('campaign_name')
    messages = request.form.get('messages')
    requirements = request.form.get('requirements')
    payment_amount = float(request.form.get('payment_amount'))
    
    new_request = AdRequest.query.filter_by(id=request_id).first()
    # Add the request to the database
    if new_request:
        new_request.messages=messages
        new_request.payment_amount=payment_amount
        new_request.requirements=requirements
        new_request.status='Pending'
    else:
        flash('Request not found.','danger')
    

    db.session.commit()

    flash('Request sent successfully!', 'success')
    return redirect(url_for('influencer_request'))



@app.route('/negotiate_sponsor/<int:request_id>', methods=['POST'])
def negotiate_sponsor(request_id):
    request_to_negotiate = AdRequest.query.get_or_404(request_id)
    negotiation_message = request.form.get('negotiation_message')
    if request_to_negotiate:
        request_to_negotiate.messages=negotiation_message
        request_to_negotiate.status = 'Rejected'
        db.session.commit()
        flash('Negotiation message sent.', 'success')
    else:
        flash('Request not found.', 'danger')
    return redirect(url_for('influencer_request'))
















#Admin--------------------------------------------------------------------------------------------------------------------------------------------




@app.route('/admin')
def admin():
    user_count = User.query.count()
    sponsor_count = Sponsor.query.count()
    influencer_count = Influencer.query.count()
    campaign_count = Campaign.query.count()
    transaction_count = Transaction.query.count()
    admin = User.query.filter_by(role='Admin').first()
    

    return render_template('admin.html',admin=admin,user_count=user_count, sponsor_count=sponsor_count,influencer_count=influencer_count,campaign_count=campaign_count,transaction_count=transaction_count)


@app.route('/verify_influencer')
def verify_influencer():
    influencer = Influencer.query.all()
    return render_template('verify_influencer.html',influencer=influencer)

@app.route('/list_admin_influencers', methods=['GET'])
def list_admin_influencers():
    name = request.args.get('name')
    niche = request.args.get('niche')
    platform = request.args.get('platform')
    sort_order = request.args.get('sortOrder', 'asc')

    # Query the database with filters
    query = Influencer.query
    
    if name:
        query = query.filter(Influencer.name.ilike(f'%{name}%'))
    if niche:
        query = query.filter(Influencer.niche.ilike(f'%{niche}%'))
    if platform:
        query = query.filter(Influencer.platform.ilike(f'%{platform}%'))

    if sort_order == 'asc':
        query = query.order_by(Influencer.reach.asc())
    else:
        query = query.order_by(Influencer.reach.desc())
    
    influencer = query.all()

    
    # Render the template with the filtered influencers
    return render_template('verify_influencer.html', influencer=influencer)

@app.route('/flag_influencer/<int:influencer_id>',methods=['POST'])
def flag_influencer(influencer_id):
    influencer = Influencer.query.get_or_404(influencer_id)
    if influencer:
        influencer.flagged=True
        db.session.commit()
        flash('Influencer flagged successfully','success')
        return redirect(url_for('verify_influencer'))
    flash('Influencer not found','danger')
    return redirect(url_for('verify_influencer'))


@app.route('/verify_sponsor')
def verify_sponsor():
    sponsor = Sponsor.query.all()
    return render_template('verify_sponsor.html',sponsor=sponsor)

@app.route('/list_admin_sponsor', methods=['GET'])
def list_admin_sponsor():
    name = request.args.get('name')
    company = request.args.get('company')

    # Query the database with filters
    query = Sponsor.query
    
    if name:
        query = query.filter(Sponsor.name.ilike(f'%{name}%'))
    
    if company:
        query = query.filter(Sponsor.company.ilike(f'%{company}%'))
    
    sponsor = query.all()

    
    # Render the template with the filtered influencers
    return render_template('verify_sponsor.html', sponsor=sponsor)

@app.route('/flag_sponsor/<int:sponsor_id>',methods=['POST'])
def flag_sponsor(sponsor_id):
    sponsor = Sponsor.query.get_or_404(sponsor_id)
    if sponsor:
        sponsor.flagged=True
        db.session.commit()
        flash('Sponsor flagged successfully','success')
        return redirect(url_for('verify_sponsor'))
    flash('Sponsor not found','danger')
    return redirect(url_for('verify_sponsor'))
    


@app.route('/verify_campaign')
def verify_campaign():
    campaign = Campaign.query.all()
    return render_template('verify_campaign.html',campaign=campaign)

@app.route('/list_admin_campaigns', methods=['GET'])
def list_admin_campaigns():
    name = request.args.get('name')
    niche = request.args.get('niche')

    # Query the database with filters
    query = Campaign.query
    
    if name:
        query = query.filter(Campaign.name.ilike(f'%{name}%'))
    
    if niche:
        query = query.filter(Campaign.niche.ilike(f'%{niche}%'))
    
    campaign = query.all()

    
    # Render the template with the filtered influencers
    return render_template('verify_campaign.html', campaign=campaign)

@app.route('/flag_campaign/<int:campaign_id>',methods=['POST'])
def flag_campaign(campaign_id):
    campaign = Campaign.query.get_or_404(campaign_id)
    if campaign:
        campaign.flagged=True
        db.session.commit()
        flash('Campaign flagged successfully','success')
        return redirect(url_for('verify_campaign'))
    flash('Campaign not found','danger')
    return redirect(url_for('verify_campaign'))


@app.route('/influencer_stats')
def influencer_stats():
    # Define the list of niche labels
    niche_labels = ['Tech', 'Fashion and Beauty', 'Fitness', 'Travel', 'Food', 'Lifestyle', 'Gaming', 'Finance', 'Entertainment']
    
    # Initialize a dictionary to hold the counts for each niche
    niche_counts = {niche: 0 for niche in niche_labels}
    
    # Query the database to get counts of influencers for each niche
    influencers = Influencer.query.all()
    
    for influencer in influencers:
        if influencer.niche in niche_counts:
            niche_counts[influencer.niche] += 1

    # Prepare the data for the chart
    labels = list(niche_counts.keys())
    counts = list(niche_counts.values())


    total_influencers = len(influencers)
    if total_influencers > 0:
        platforms = [inf.platform for inf in influencers]
        niches = [inf.niche for inf in influencers]
        bank_balances = [inf.bank_balance for inf in influencers]
        reaches = [inf.reach for inf in influencers]

        most_common_platform = max(set(platforms), key=platforms.count)
        most_common_niche = max(set(niches), key=niches.count)
        average_bank_balance = sum(bank_balances) / total_influencers
        average_reach = sum(reaches) / total_influencers
    else:
        most_common_platform = "N/A"
        most_common_niche = "N/A"
        average_bank_balance = 0
        average_reach = 0

    return render_template(
        'influencer_stats.html',
        total_influencers=total_influencers,
        most_common_platform=most_common_platform,
        most_common_niche=most_common_niche,
        average_bank_balance=average_bank_balance,
        average_reach=average_reach,
        labels=labels,
        counts=counts
    )


@app.route('/campaign_stats')
def campaign_stats():
    # Fetch all campaigns
    campaigns = Campaign.query.all()
    
    # Calculate statistics
    number_of_campaigns = len(campaigns)
    total_budget = sum(campaign.budget for campaign in campaigns)
    average_budget = total_budget / number_of_campaigns if number_of_campaigns > 0 else 0

    # Calculate most popular campaign niche
    niche_labels = ['Tech', 'Fashion and Beauty', 'Fitness', 'Travel', 'Food', 'Lifestyle', 'Gaming', 'Finance', 'Entertainment']
    
    # Initialize a dictionary to hold the counts for each niche
    niche_count = {niche: 0 for niche in niche_labels}

    for campaign in campaigns:
        if campaign.niche in niche_count:
            niche_count[campaign.niche] += 1
        else:
            niche_count[campaign.niche] = 1
    most_popular_niche = max(niche_count, key=niche_count.get, default='None')

    # Prepare data for the bar chart (campaigns by niche)
    niches = list(niche_count.keys())
    niche_counts = list(niche_count.values())

    # Prepare data for the pie chart (campaigns by niche)
    niche_pie_data = {
        "labels": niches,
        "data": niche_counts
    }

    # Prepare data for the pie chart (campaigns by visibility)
    visibility_count = {
        "Public": 0,
        "Private": 0
    }
    for campaign in campaigns:
        if campaign.visibility == 'Public':
            visibility_count["Public"] += 1
        else:
            visibility_count["Private"] += 1
    visibility_pie_data = {
        "labels": list(visibility_count.keys()),
        "data": list(visibility_count.values())
    }

    # Pass the metrics and chart data to the template
    return render_template('campaign_stats.html',
                           number_of_campaigns=number_of_campaigns,
                           total_budget=total_budget,
                           average_budget=average_budget,
                           most_popular_niche=most_popular_niche,
                           niche_pie_data=niche_pie_data,
                           visibility_pie_data=visibility_pie_data,
                           niche_labels=niches,
                           niche_counts=niche_counts)


@app.route('/flagged_influencer')
def flagged_influencer():
    
    flagged_influencers = Influencer.query.filter_by(flagged=True).all()
    return render_template('flagged_influencer.html', influencer=flagged_influencers)



@app.route('/reinstate_influencer/<int:influencer_id>', methods=['POST'])
def reinstate_influencer(influencer_id):
    influencer = Influencer.query.get_or_404(influencer_id)
    influencer.flagged = False
    db.session.commit()
    flash('Influencer reinstated successfully!', 'success')
    return redirect(url_for('flagged_influencer'))


@app.route('/delete_influencer/<int:influencer_id>', methods=['POST'])
def delete_influencer(influencer_id):
    influencer = Influencer.query.get_or_404(influencer_id)

    # Delete related CampaignRequests
    CampaignRequest.query.filter_by(influencer_id=influencer_id).delete()

    # Delete related AdRequests
    AdRequest.query.filter_by(influencer_id=influencer_id).delete()

    # Delete related Transactions
    Transaction.query.filter_by(influencer_id=influencer_id).delete()

    # Delete the influencer
    db.session.delete(influencer)

    # Optionally, delete the associated user if they are not linked to any other records
    user = User.query.get(influencer.user_id)
    if user and not user.influencers and not user.campaigns and not user.sponsor and not user.bookmarks and not user.transactions:
        db.session.delete(user)

    db.session.commit()
    
    flash('Influencer and related records deleted successfully!', 'success')
    return redirect(url_for('flagged_influencer'))


@app.route('/flagged_sponsors')
def flagged_sponsors():
    flagged_sponsors = Sponsor.query.filter_by(flagged=True).all()
    return render_template('flagged_sponsors.html', sponsor=flagged_sponsors)



@app.route('/reinstate_sponsor/<int:sponsor_id>', methods=['POST'])
def reinstate_sponsor(sponsor_id):
    sponsor = Sponsor.query.get_or_404(sponsor_id)
    sponsor.flagged = False
    db.session.commit()
    flash('Sponsor reinstated successfully!', 'success')
    return redirect(url_for('flagged_sponsors'))


@app.route('/delete_sponsor/<int:sponsor_id>', methods=['POST'])
def delete_sponsor(sponsor_id):
    sponsor = Sponsor.query.get_or_404(sponsor_id)

    # Delete related Campaigns (if needed, depending on the relationship)
    Campaign.query.filter_by(user_id=sponsor.user_id).delete()

    # Delete related CampaignRequests (if needed, depending on the relationship)
    CampaignRequest.query.filter_by(sponsor_id=sponsor_id).delete()

    # Delete related AdRequests
    AdRequest.query.filter_by(sponsor_id=sponsor_id).delete()

    # Delete related Transactions (if any)
    Transaction.query.filter_by(user_id=sponsor.user_id).delete()

    # Delete the sponsor
    db.session.delete(sponsor)

    # Optionally, delete the associated user if they are not linked to any other records
    user = User.query.get(sponsor.user_id)
    if user and not user.influencers and not user.campaigns and not user.sponsor and not user.bookmarks and not user.transactions:
        db.session.delete(user)

    db.session.commit()
    
    flash('Sponsor and related records deleted successfully!', 'success')
    return redirect(url_for('flagged_sponsors'))


@app.route('/flagged_campaigns')
def flagged_campaigns():
    flagged_campaigns = Campaign.query.filter_by(flagged=True).all()
    return render_template('flagged_campaigns.html', campaign=flagged_campaigns)




@app.route('/reinstate_campaign/<int:campaign_id>', methods=['POST'])
def reinstate_campaign(campaign_id):
    campaign = Campaign.query.get_or_404(campaign_id)
    campaign.flagged = False
    db.session.commit()
    flash('Campaign reinstated successfully!', 'success')
    return redirect(url_for('flagged_campaigns'))
 


@app.route('/remove_campaign/<int:campaign_id>', methods=['POST'])
def remove_campaign(campaign_id):
    campaign = Campaign.query.get_or_404(campaign_id)

    # Delete related CampaignRequests
    CampaignRequest.query.filter_by(campaign_id=campaign_id).delete()

    # Delete related AdRequests
    AdRequest.query.filter_by(campaign_id=campaign_id).delete()

    # Optionally, delete the campaign if it has no other dependencies
    db.session.delete(campaign)

    # Optionally, delete the associated user if they are not linked to any other records
    user = User.query.get(campaign.user_id)
    if user and not user.influencers and not user.campaigns and not user.sponsor and not user.bookmarks and not user.transactions:
        db.session.delete(user)

    db.session.commit()
    
    flash('Campaign and related records deleted successfully!', 'success')
    return redirect(url_for('flagged_campaigns'))











@app.route('/transaction_stats')
def transaction_stats():
    # Fetch transaction data
    transactions = db.session.query(Transaction).all()
    
    # Calculate statistics
    total_transactions = len(transactions)
    total_transaction_amount = sum(t.amount for t in transactions)
    average_transaction_amount = (total_transaction_amount / total_transactions) if total_transactions > 0 else 0
    
    # Prepare data for chart
    transaction_dates = [t.date.strftime('%Y-%m-%d') for t in transactions]
    transaction_amounts = [t.amount for t in transactions]
    
    return render_template('transaction_stats.html',
                           total_transactions=total_transactions,
                           total_transaction_amount=total_transaction_amount,
                           average_transaction_amount=average_transaction_amount,
                           transaction_dates=transaction_dates,
                           transaction_amounts=transaction_amounts)


